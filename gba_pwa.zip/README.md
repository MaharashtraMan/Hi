# GBA PWA

This is a simple Progressive Web App (PWA) for running Game Boy Advance ROMs
using [gba.js](https://github.com/endrift/gbajs).

⚠️ No ROMs are included. You must supply your own `.gba` files (homebrew or
legally dumped cartridges).

## Features
- Installable on ChromeOS as a standalone app (no Linux needed)
- Loads local `.gba` files via file picker
- Runs in a clean PWA window with app icon

## Deployment (GitHub Pages)
1. Fork or upload this folder to a GitHub repo
2. In repo settings → Pages → Enable GitHub Pages (branch: main, root)
3. Visit `https://<username>.github.io/<repo>/` in Chrome
4. Use ⋮ menu → **Install App**

## Controls
- Arrow keys = D-Pad
- Z = A
- X = B
- Enter = Start
- Backspace = Select

## Legal
Emulators are legal. Distributing or downloading copyrighted ROMs is not.
Use only ROMs you legally own or homebrew/public domain games.
